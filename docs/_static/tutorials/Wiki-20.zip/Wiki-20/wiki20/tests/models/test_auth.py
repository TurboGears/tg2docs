# -*- coding: utf-8 -*-
"""Test suite for the TG app's models"""
from nose.tools import eq_

from wiki20 import model
from wiki20.tests.models import ModelTest

