# -*- coding: utf-8 -*-
"""Sample controller with all its actions protected."""

# This controller is only used when you activate auth. You can safely remove
# this file from your project.
