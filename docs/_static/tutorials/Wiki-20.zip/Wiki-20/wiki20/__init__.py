# -*- coding: utf-8 -*-
"""The Wiki-20 package"""
